-- Milk Tea

INSERT INTO products(name, price, image, prod_type, sub_category) VALUES ('Bubble Milk Tea', 45000, 'prod_img/milk/milk_tea/bubble-milk.jpg', 'Milk', 'Milk Tea');

INSERT INTO products(name, price, image, prod_type, sub_category) VALUES ('Golden Green Tea', 39000, 'prod_img/milk/milk_tea/goldengreen-milk.jpg', 'Milk', 'Milk Tea');

INSERT INTO products(name, price, image, prod_type, sub_category) VALUES ('Neptune Milk Tea', 55000, 'prod_img/milk/milk_tea/neptune-milk.jpg', 'Milk', 'Milk Tea');

INSERT INTO products(name, price, image, prod_type, sub_category) VALUES ('Rose Puer Milk Tea', 55000, 'prod_img/milk/milk_tea/rosepuer-milk.jpg', 'Milk', 'Milk Tea');


INSERT INTO products(name, price, image, prod_type, sub_category) VALUES ('Signature Milk Tea', 39000, 'prod_img/milk/milk_tea/signature-milk.jpg', 'Milk', 'Milk Tea');

INSERT INTO products(name, price, image, prod_type, sub_category) VALUES ('HongKong Milk Tea', 62000, 'prod_img/milk/milk_tea/hongkong-milk.jpg', 'Milk', 'Milk Tea');

INSERT INTO products(name, price, image, prod_type, sub_category) VALUES ('Roasted Oolong Milk Tea', 55000, 'prod_img/milk/milk_tea/roastedoolong-milk.jpg', 'Milk', 'Milk Tea');

INSERT INTO products(name, price, image, prod_type, sub_category) VALUES ('Herb Jelly Milk Tea', 45000, 'prod_img/milk/milk_tea/herbjelly-milk.jpg', 'Milk', 'Milk Tea');


INSERT INTO products(name, price, image, prod_type, sub_category) VALUES ('Honey Milk Tea', 43000, 'prod_img/milk/milk_tea/honey-milk-tea.jpg', 'Milk', 'Milk Tea');

INSERT INTO products(name, price, image, prod_type, sub_category) VALUES ('Mango Milk Tea', 48000, 'prod_img/milk/milk_tea/mango-milk-tea.jpg', 'Milk', 'Milk Tea');

INSERT INTO products(name, price, image, prod_type, sub_category) VALUES ('Taro Milk Tea', 48000, 'prod_img/milk/milk_tea/taro-milk-tea.jpg', 'Milk', 'Milk Tea');

-- Milk

INSERT INTO products(name, price, image, prod_type, sub_category) VALUES ('Bubble Fresh Milk', 48000, 'prod_img/milk/fresh_milk/bubble-fresh-milk.jpg', 'Milk', 'Fresh Milk');

INSERT INTO products(name, price, image, prod_type, sub_category) VALUES ('Cocoa Fresh Milk', 53000, 'prod_img/milk/fresh_milk/cocoa-fresh-milk.jpg', 'Milk', 'Fresh Milk');

INSERT INTO products(name, price, image, prod_type, sub_category) VALUES ('Herb Fresh Milk', 48000, 'prod_img/milk/fresh_milk/herb-fresh-milk.jpg', 'Milk', 'Fresh Milk');

INSERT INTO products(name, price, image, prod_type, sub_category) VALUES ('Matcha Fresh Milk', 48000, 'prod_img/milk/fresh_milk/matcha-fresh-milk.jpg', 'Milk', 'Fresh Milk');



